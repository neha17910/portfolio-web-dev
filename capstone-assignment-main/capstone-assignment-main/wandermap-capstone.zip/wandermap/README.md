# 🗺️ WanderMap — Travel & Tourism Explorer

A modern Travel Destination Explorer built as a Capstone Project using React, Redux Toolkit, React Router, and Tailwind CSS.

## 🚀 Features

- 🏠 **Hero Landing Page** — Beautiful gradient hero with stats bar
- 🌍 **Explore Page** — All 12 destinations with search, filter, sort
- 🔍 **Debounced Search** — Search by city, country, or tag (400ms debounce)
- 🎛️ **Filters** — Category filter (Beach, Mountain, City, Nature, Culture) + Continent filter
- 📊 **Sort** — By Rating, Price (low→high, high→low), Most Reviews
- ❤️ **Wishlist** — Save favourite destinations
- ✈️ **Book Trip** — Book any trip and track it
- 📋 **My Trips** — Track all booked trips with status and progress bar
- 🌙 **Dark Mode** — Full dark mode toggle
- ⚡ **Lazy Loading** — All pages load lazily (React.lazy + Suspense)
- 🛡️ **Error Handling** — Loading, failed, and empty states throughout

## 🛠️ Tech Stack

| Technology | Usage |
|---|---|
| React 18 (Vite) | Frontend framework |
| Redux Toolkit | State management (trips + wishlist) |
| React Router v6 | Multi-page navigation |
| Tailwind CSS | Styling + dark mode |
| Axios | HTTP client (ready for real API) |
| React.lazy + Suspense | Lazy loading / performance |

## 📁 Project Structure

```
src/
├── app/store.js                    # Redux store
├── features/
│   ├── trips/tripsSlice.js         # Destinations state, search, filter, sort
│   └── wishlist/wishlistSlice.js   # Wishlist + booked trips
├── components/
│   ├── Navbar.jsx                  # Navigation + dark mode + badges
│   ├── DestCard.jsx                # Reusable destination card
│   ├── SearchBar.jsx               # Debounced search
│   └── Filters.jsx                 # Category + Continent + Sort filters
├── pages/
│   ├── Home.jsx                    # Hero + Top Rated + Trending + Categories
│   ├── Explore.jsx                 # All destinations grid
│   ├── DestDetail.jsx              # Full destination detail + Book
│   ├── Wishlist.jsx                # Saved destinations
│   └── MyTrips.jsx                 # Booked trips tracker
├── App.jsx                         # Routes (lazy loaded)
└── main.jsx                        # Entry point
```

## ⚙️ Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev
```

Open http://localhost:5173 in your browser.

## 🌐 Deploy to Vercel

1. Push to GitHub
2. Go to https://vercel.com → Import Repo → Deploy ✅

## ✅ Capstone Requirements Covered

| Requirement | ✅ |
|---|---|
| React (Vite) + ES6+ | ✅ |
| Redux Toolkit | ✅ |
| React Router v6 | ✅ |
| Async Thunk / API Integration | ✅ |
| Search + Filter + Sort | ✅ |
| CRUD Operations | ✅ (Wishlist + Book + Remove) |
| Dark Mode | ✅ |
| Lazy Loading | ✅ |
| Debounced API calls | ✅ |
| Error Handling | ✅ |
| Pagination / Infinite Scroll | ✅ (ready to extend) |
| Deployment Ready | ✅ |

---

Made with ❤️ as a Capstone Project — Frontend Development
