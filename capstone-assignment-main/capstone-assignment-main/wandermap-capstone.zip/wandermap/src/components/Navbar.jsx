import { Link, useLocation } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { useState } from 'react'

export default function Navbar() {
  const location   = useLocation()
  const [dark, setDark] = useState(false)
  const wishCount  = useSelector(s => s.wishlist.ids.length)
  const tripCount  = useSelector(s => s.wishlist.booked.length)

  const toggleDark = () => {
    setDark(!dark)
    document.documentElement.classList.toggle('dark')
  }

  const link = (to, label, badge) => (
    <Link
      to={to}
      className={`relative px-3 py-1.5 rounded-lg font-medium text-sm transition ${
        location.pathname === to
          ? 'bg-white text-blue-600'
          : 'text-white hover:bg-blue-500'
      }`}
    >
      {label}
      {badge > 0 && (
        <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
          {badge}
        </span>
      )}
    </Link>
  )

  return (
    <nav className="bg-blue-600 dark:bg-gray-900 text-white px-6 py-4 shadow-md sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold flex items-center gap-2">
          🗺️ <span>WanderMap</span>
        </Link>
        <div className="flex items-center gap-2">
          {link('/', 'Home')}
          {link('/explore', 'Explore')}
          {link('/wishlist', '❤️ Wishlist', wishCount)}
          {link('/my-trips', '✈️ My Trips', tripCount)}
          <button
            onClick={toggleDark}
            className="ml-2 px-3 py-1.5 rounded-lg bg-blue-500 dark:bg-gray-700 hover:opacity-90 transition text-sm"
          >
            {dark ? '☀️' : '🌙'}
          </button>
        </div>
      </div>
    </nav>
  )
}
