import { useDispatch, useSelector } from 'react-redux'
import { toggleWishlist } from '../features/wishlist/wishlistSlice'
import { Link } from 'react-router-dom'

export default function DestCard({ dest }) {
  const dispatch  = useDispatch()
  const wished    = useSelector(s => s.wishlist.ids.includes(dest.id))
  const booked    = useSelector(s => s.wishlist.booked.includes(dest.id))

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden border border-gray-100 dark:border-gray-700">
      {/* Card Image Area */}
      <div className={`relative h-44 bg-gradient-to-br ${dest.bg} flex items-center justify-center`}>
        <span className="text-7xl drop-shadow-lg">{dest.emoji}</span>
        <button
          onClick={() => dispatch(toggleWishlist(dest.id))}
          className="absolute top-3 right-3 text-2xl hover:scale-110 transition-transform bg-white/30 backdrop-blur-sm rounded-full p-1.5"
        >
          {wished ? '❤️' : '🤍'}
        </button>
        {booked && (
          <div className="absolute top-3 left-3 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-semibold">
            ✅ Booked
          </div>
        )}
        <div className="absolute bottom-3 left-3 bg-black/30 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full">
          ⏱ {dest.duration}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5">
        <div className="flex justify-between items-start mb-1">
          <h2 className="font-bold text-lg text-gray-900 dark:text-white leading-tight">{dest.name}</h2>
          <div className="flex items-center gap-1 text-amber-500 text-sm font-semibold shrink-0">
            ⭐ {dest.rating}
          </div>
        </div>

        <p className="text-xs text-gray-400 dark:text-gray-500 mb-3">
          🌍 {dest.country} · 🗓 Best: {dest.bestTime} · 💬 {dest.reviews.toLocaleString()} reviews
        </p>

        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-4">{dest.description}</p>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {dest.tags.slice(0, 3).map(tag => (
            <span key={tag} className="bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2.5 py-1 rounded-full font-medium">
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs text-gray-400">Starting from</span>
            <p className="text-xl font-bold text-blue-600 dark:text-blue-400">
              ₹{dest.price.toLocaleString()}
            </p>
          </div>
          <Link
            to={`/dest/${dest.id}`}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition active:scale-95"
          >
            Explore →
          </Link>
        </div>
      </div>
    </div>
  )
}
