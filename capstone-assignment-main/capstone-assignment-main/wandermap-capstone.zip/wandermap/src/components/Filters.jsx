import { useDispatch, useSelector } from 'react-redux'
import { setFilterCategory, setFilterContinent, setSortBy } from '../features/trips/tripsSlice'

const CATEGORIES  = ['All', 'Beach', 'Mountain', 'City', 'Nature', 'Culture']
const CONTINENTS  = ['All', 'Asia', 'Europe', 'Americas']

export default function Filters() {
  const dispatch   = useDispatch()
  const { filterCategory, filterContinent, sortBy } = useSelector(s => s.trips)

  return (
    <div className="space-y-3">
      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => dispatch(setFilterCategory(c))}
            className={`px-4 py-2 rounded-full text-sm font-medium border-2 transition ${
              filterCategory === c
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white dark:bg-gray-800 dark:text-white border-gray-200 dark:border-gray-600 hover:border-blue-400'
            }`}
          >
            {{All:'🌐', Beach:'🏖️', Mountain:'🏔️', City:'🏙️', Nature:'🌿', Culture:'🏛️'}[c]} {c}
          </button>
        ))}
      </div>

      {/* Continent + Sort */}
      <div className="flex flex-wrap gap-3">
        <select
          value={filterContinent}
          onChange={e => dispatch(setFilterContinent(e.target.value))}
          className="border-2 border-gray-200 dark:border-gray-600 rounded-xl px-4 py-2 bg-white dark:bg-gray-800 dark:text-white text-sm focus:outline-none focus:border-blue-400"
        >
          {CONTINENTS.map(c => <option key={c}>{c}</option>)}
        </select>
        <select
          value={sortBy}
          onChange={e => dispatch(setSortBy(e.target.value))}
          className="border-2 border-gray-200 dark:border-gray-600 rounded-xl px-4 py-2 bg-white dark:bg-gray-800 dark:text-white text-sm focus:outline-none focus:border-blue-400"
        >
          <option value="rating">Sort: Top Rated</option>
          <option value="price_low">Sort: Price Low→High</option>
          <option value="price_high">Sort: Price High→Low</option>
          <option value="reviews">Sort: Most Reviews</option>
        </select>
      </div>
    </div>
  )
}
