import { useDispatch } from 'react-redux'
import { setSearch } from '../features/trips/tripsSlice'
import { useCallback } from 'react'

function debounce(fn, delay) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), delay) }
}

export default function SearchBar({ placeholder = 'Search destinations...' }) {
  const dispatch = useDispatch()
  const handle = useCallback(debounce(v => dispatch(setSearch(v)), 400), [])

  return (
    <div className="relative">
      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-xl">🔍</span>
      <input
        type="text"
        placeholder={placeholder}
        onChange={e => handle(e.target.value)}
        className="w-full border-2 border-gray-200 dark:border-gray-600 rounded-xl pl-12 pr-4 py-3 text-base bg-white dark:bg-gray-800 dark:text-white focus:outline-none focus:border-blue-400 transition"
      />
    </div>
  )
}
