import { Routes, Route } from 'react-router-dom'
import { lazy, Suspense } from 'react'
import Navbar from './components/Navbar'

const Home         = lazy(() => import('./pages/Home'))
const Explore      = lazy(() => import('./pages/Explore'))
const DestDetail   = lazy(() => import('./pages/DestDetail'))
const Wishlist     = lazy(() => import('./pages/Wishlist'))
const MyTrips      = lazy(() => import('./pages/MyTrips'))

function Spinner() {
  return (
    <div className="flex justify-center items-center py-32">
      <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
    </div>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Navbar />
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/"            element={<Home />} />
          <Route path="/explore"     element={<Explore />} />
          <Route path="/dest/:id"    element={<DestDetail />} />
          <Route path="/wishlist"    element={<Wishlist />} />
          <Route path="/my-trips"    element={<MyTrips />} />
          <Route path="*"            element={<Home />} />
        </Routes>
      </Suspense>
    </div>
  )
}
