import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchDestinations } from '../features/trips/tripsSlice'
import DestCard from '../components/DestCard'
import SearchBar from '../components/SearchBar'
import Filters from '../components/Filters'

export default function Explore() {
  const dispatch = useDispatch()
  const { list, status, search, filterCategory, filterContinent, sortBy } = useSelector(s => s.trips)

  useEffect(() => { if (status === 'idle') dispatch(fetchDestinations()) }, [])

  const filtered = list
    .filter(d => {
      const q = search.toLowerCase()
      const matchQ = d.name.toLowerCase().includes(q) ||
                     d.country.toLowerCase().includes(q) ||
                     d.tags.some(t => t.toLowerCase().includes(q))
      const matchC = filterCategory  === 'All' || d.category  === filterCategory
      const matchCo = filterContinent === 'All' || d.continent === filterContinent
      return matchQ && matchC && matchCo
    })
    .sort((a, b) => {
      if (sortBy === 'rating')      return b.rating - a.rating
      if (sortBy === 'price_low')   return a.price - b.price
      if (sortBy === 'price_high')  return b.price - a.price
      if (sortBy === 'reviews')     return b.reviews - a.reviews
      return 0
    })

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold dark:text-white mb-1">🌍 Explore Destinations</h1>
        <p className="text-gray-400">Discover your next adventure from {list.length} amazing places</p>
      </div>

      <div className="space-y-4 mb-8">
        <SearchBar placeholder="🔍 Search by city, country or tag..." />
        <Filters />
      </div>

      {status === 'loading' && (
        <div className="flex flex-col items-center py-24 gap-4">
          <div className="w-14 h-14 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          <p className="text-gray-400">Finding amazing destinations...</p>
        </div>
      )}

      {status === 'failed' && (
        <div className="text-center py-24">
          <p className="text-5xl mb-4">⚠️</p>
          <p className="text-red-500 font-semibold text-lg">Failed to load destinations</p>
          <button onClick={() => dispatch(fetchDestinations())}
            className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700">
            Try Again
          </button>
        </div>
      )}

      {status === 'succeeded' && (
        <>
          <p className="text-gray-500 dark:text-gray-400 mb-5 font-medium">
            Showing <span className="text-blue-600 font-bold">{filtered.length}</span> destinations
          </p>
          {filtered.length === 0 ? (
            <div className="text-center py-24">
              <p className="text-6xl mb-4">🔍</p>
              <p className="text-gray-500 dark:text-gray-400 text-lg">No destinations match your search</p>
              <p className="text-gray-400 text-sm mt-2">Try different keywords or filters</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filtered.map(d => <DestCard key={d.id} dest={d} />)}
            </div>
          )}
        </>
      )}
    </div>
  )
}
