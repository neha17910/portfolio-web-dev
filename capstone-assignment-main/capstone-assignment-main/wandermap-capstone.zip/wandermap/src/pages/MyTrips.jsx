import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'

const TRIP_STATUSES = ['Confirmed', 'Planning', 'Upcoming', 'Completed']
const STATUS_STYLE  = {
  Confirmed: 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300',
  Planning:  'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300',
  Upcoming:  'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300',
  Completed: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300',
}

export default function MyTrips() {
  const { booked } = useSelector(s => s.wishlist)
  const list       = useSelector(s => s.trips.list)
  const trips      = list.filter(d => booked.includes(d.id))

  const getStatus = (id) => TRIP_STATUSES[id % TRIP_STATUSES.length]

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold dark:text-white">✈️ My Trips</h1>
        <p className="text-gray-400 mt-1">{trips.length} trips booked</p>
      </div>

      {/* Summary Cards */}
      {trips.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { icon: '✈️', label: 'Total Trips',   value: trips.length },
            { icon: '💰', label: 'Total Spent',   value: `₹${trips.reduce((s,d) => s + d.price, 0).toLocaleString()}` },
            { icon: '🌍', label: 'Countries',     value: new Set(trips.map(d => d.country)).size },
            { icon: '⭐', label: 'Avg Rating',    value: (trips.reduce((s,d) => s + d.rating, 0) / trips.length).toFixed(1) },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-700 text-center">
              <div className="text-3xl mb-1">{s.icon}</div>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{s.value}</div>
              <div className="text-xs text-gray-400 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Trip List */}
      {trips.length === 0 ? (
        <div className="text-center py-28 bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700">
          <p className="text-7xl mb-4">🧳</p>
          <p className="text-xl font-semibold dark:text-white mb-2">No trips booked yet</p>
          <p className="text-gray-400 mb-8">Book your first trip and it will appear here</p>
          <Link to="/explore"
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-2xl font-semibold transition">
            🌍 Explore Destinations
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {trips.map(d => {
            const status = getStatus(d.id)
            return (
              <div key={d.id} className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${d.bg} flex items-center justify-center text-3xl shadow`}>
                      {d.emoji}
                    </div>
                    <div>
                      <h3 className="font-bold text-lg dark:text-white">{d.name}</h3>
                      <p className="text-gray-400 text-sm">
                        🌍 {d.country} · ⏱ {d.duration} · 🗓 Best: {d.bestTime}
                      </p>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {d.tags.slice(0,3).map(t => (
                          <span key={t} className="bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs px-2 py-0.5 rounded-full">{t}</span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 ml-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${STATUS_STYLE[status]}`}>
                      {status}
                    </span>
                    <p className="text-xl font-bold text-blue-600 dark:text-blue-400 mt-2">
                      ₹{d.price.toLocaleString()}
                    </p>
                    <Link to={`/dest/${d.id}`}
                      className="text-xs text-blue-500 hover:underline">
                      View Details →
                    </Link>
                  </div>
                </div>

                {/* Progress */}
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Booked</span><span>Planning</span><span>Upcoming</span><span>Completed</span>
                  </div>
                  <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-2 bg-blue-500 rounded-full transition-all" style={{
                      width: status==='Confirmed'?'25%': status==='Planning'?'50%': status==='Upcoming'?'75%':'100%'
                    }}></div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
