import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchDestinations } from '../features/trips/tripsSlice'
import { Link } from 'react-router-dom'
import DestCard from '../components/DestCard'

export default function Home() {
  const dispatch = useDispatch()
  const { list, status } = useSelector(s => s.trips)

  useEffect(() => { if (status === 'idle') dispatch(fetchDestinations()) }, [])

  const topRated = [...list].sort((a, b) => b.rating - a.rating).slice(0, 3)
  const trending = list.filter(d => ['Bali, Indonesia', 'Goa, India', 'Dubai, UAE'].includes(d.name))

  return (
    <div>
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10 text-9xl flex flex-wrap gap-8 p-8 select-none pointer-events-none">
          {['✈️','🌍','🏖️','🗼','🏔️','🗺️','🌴','🏛️','🌺','🐠'].map((e,i) => (
            <span key={i} className="animate-pulse">{e}</span>
          ))}
        </div>
        <div className="relative max-w-6xl mx-auto px-6 py-24 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Explore the World with<br />
            <span className="text-yellow-300">WanderMap 🗺️</span>
          </h1>
          <p className="text-blue-100 text-xl max-w-2xl mx-auto mb-10">
            Discover breathtaking destinations, plan your dream trip, and create memories that last a lifetime.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link to="/explore"
              className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold px-8 py-4 rounded-2xl text-lg transition active:scale-95 shadow-lg">
              🔍 Explore Destinations
            </Link>
            <Link to="/wishlist"
              className="bg-white/20 hover:bg-white/30 backdrop-blur text-white font-bold px-8 py-4 rounded-2xl text-lg transition border-2 border-white/30">
              ❤️ My Wishlist
            </Link>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b dark:border-gray-700">
        <div className="max-w-6xl mx-auto px-6 py-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { icon: '🌍', value: '12+',    label: 'Destinations' },
            { icon: '⭐', value: '4.8',    label: 'Avg Rating' },
            { icon: '👥', value: '50K+',   label: 'Happy Travellers' },
            { icon: '🌏', value: '3',      label: 'Continents' },
          ].map(s => (
            <div key={s.label}>
              <div className="text-3xl mb-1">{s.icon}</div>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{s.value}</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-14">

        {/* Top Rated */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold dark:text-white">⭐ Top Rated Destinations</h2>
              <p className="text-gray-400 text-sm mt-1">Loved by travellers worldwide</p>
            </div>
            <Link to="/explore" className="text-blue-600 dark:text-blue-400 font-semibold hover:underline text-sm">
              View All →
            </Link>
          </div>
          {status === 'loading' ? (
            <div className="flex justify-center py-16">
              <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {topRated.map(d => <DestCard key={d.id} dest={d} />)}
            </div>
          )}
        </section>

        {/* Trending */}
        {trending.length > 0 && (
          <section>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold dark:text-white">🔥 Trending Now</h2>
                <p className="text-gray-400 text-sm mt-1">Most booked this season</p>
              </div>
              <Link to="/explore" className="text-blue-600 dark:text-blue-400 font-semibold hover:underline text-sm">
                View All →
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {trending.map(d => <DestCard key={d.id} dest={d} />)}
            </div>
          </section>
        )}

        {/* Categories */}
        <section>
          <h2 className="text-2xl font-bold dark:text-white mb-6">🗂️ Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { icon: '🏖️', label: 'Beach',    bg: 'from-orange-400 to-pink-500',   count: list.filter(d=>d.category==='Beach').length },
              { icon: '🏔️', label: 'Mountain', bg: 'from-green-400 to-teal-500',    count: list.filter(d=>d.category==='Mountain').length },
              { icon: '🏙️', label: 'City',     bg: 'from-blue-400 to-indigo-500',   count: list.filter(d=>d.category==='City').length },
              { icon: '🌿', label: 'Nature',   bg: 'from-emerald-400 to-green-600', count: list.filter(d=>d.category==='Nature').length },
              { icon: '🏛️', label: 'Culture',  bg: 'from-amber-400 to-orange-500',  count: list.filter(d=>d.category==='Culture').length },
              { icon: '✨', label: 'All',       bg: 'from-purple-400 to-pink-500',   count: list.length },
            ].map(c => (
              <Link
                key={c.label}
                to={`/explore`}
                className={`bg-gradient-to-br ${c.bg} rounded-2xl p-6 text-white text-center hover:scale-105 transition-transform shadow-md`}
              >
                <div className="text-4xl mb-2">{c.icon}</div>
                <div className="font-bold text-lg">{c.label}</div>
                <div className="text-white/80 text-sm">{c.count} places</div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
