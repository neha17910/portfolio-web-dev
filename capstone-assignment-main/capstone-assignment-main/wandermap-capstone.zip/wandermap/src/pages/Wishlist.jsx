import { useSelector } from 'react-redux'
import DestCard from '../components/DestCard'
import { Link } from 'react-router-dom'

export default function Wishlist() {
  const { ids }  = useSelector(s => s.wishlist)
  const list     = useSelector(s => s.trips.list)
  const saved    = list.filter(d => ids.includes(d.id))

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold dark:text-white">❤️ My Wishlist</h1>
        <p className="text-gray-400 mt-1">{saved.length} destinations saved</p>
      </div>

      {saved.length === 0 ? (
        <div className="text-center py-28 bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700">
          <p className="text-7xl mb-4">🤍</p>
          <p className="text-xl font-semibold dark:text-white mb-2">Your wishlist is empty</p>
          <p className="text-gray-400 mb-8">Save destinations you love by clicking the heart icon</p>
          <Link to="/explore"
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-2xl font-semibold transition">
            🌍 Explore Destinations
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {saved.map(d => <DestCard key={d.id} dest={d} />)}
        </div>
      )}
    </div>
  )
}
