import { useParams, Link } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { toggleWishlist, bookTrip } from '../features/wishlist/wishlistSlice'
import { useState } from 'react'

export default function DestDetail() {
  const { id }     = useParams()
  const dispatch   = useDispatch()
  const dest       = useSelector(s => s.trips.list.find(d => d.id === Number(id)))
  const wished     = useSelector(s => s.wishlist.ids.includes(Number(id)))
  const booked     = useSelector(s => s.wishlist.booked.includes(Number(id)))
  const [showSuccess, setShowSuccess] = useState(false)

  if (!dest) return (
    <div className="text-center py-24 dark:text-white">
      <p className="text-6xl mb-4">😕</p>
      <p className="text-xl font-semibold mb-3">Destination not found</p>
      <Link to="/explore" className="text-blue-500 hover:underline">← Back to Explore</Link>
    </div>
  )

  const handleBook = () => {
    dispatch(bookTrip(dest.id))
    setShowSuccess(true)
    setTimeout(() => setShowSuccess(false), 3000)
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <Link to="/explore" className="text-blue-500 hover:underline flex items-center gap-1 mb-6 text-sm">
        ← Back to Explore
      </Link>

      {showSuccess && (
        <div className="bg-green-100 dark:bg-green-900/40 border border-green-300 dark:border-green-700 text-green-700 dark:text-green-300 px-6 py-4 rounded-2xl mb-6 font-medium">
          🎉 Trip booked successfully! Check My Trips to view it.
        </div>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-lg overflow-hidden">
        {/* Hero Banner */}
        <div className={`relative h-64 bg-gradient-to-br ${dest.bg} flex items-center justify-center`}>
          <span className="text-9xl drop-shadow-2xl">{dest.emoji}</span>
          <button
            onClick={() => dispatch(toggleWishlist(dest.id))}
            className="absolute top-5 right-5 text-3xl bg-white/30 backdrop-blur-sm rounded-full p-2 hover:scale-110 transition-transform"
          >
            {wished ? '❤️' : '🤍'}
          </button>
          {booked && (
            <div className="absolute top-5 left-5 bg-green-500 text-white px-4 py-1.5 rounded-full font-semibold text-sm">
              ✅ Booked
            </div>
          )}
        </div>

        <div className="p-8">
          {/* Title & Rating */}
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-3xl font-bold dark:text-white">{dest.name}</h1>
              <p className="text-gray-500 dark:text-gray-400 mt-1">
                🌍 {dest.country} · {dest.continent} · {dest.category}
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-amber-500 font-bold text-xl">
                ⭐ {dest.rating}
              </div>
              <p className="text-xs text-gray-400">{dest.reviews.toLocaleString()} reviews</p>
            </div>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { icon: '💰', label: 'Starting Price',  value: `₹${dest.price.toLocaleString()}` },
              { icon: '⏱️', label: 'Duration',         value: dest.duration },
              { icon: '🗓️', label: 'Best Time',        value: dest.bestTime },
              { icon: '🏷️', label: 'Category',         value: dest.category },
            ].map(i => (
              <div key={i.label} className="bg-gray-50 dark:bg-gray-700/50 rounded-2xl p-4 text-center">
                <div className="text-2xl mb-1">{i.icon}</div>
                <div className="text-xs text-gray-400 mb-1">{i.label}</div>
                <div className="font-semibold text-sm dark:text-white">{i.value}</div>
              </div>
            ))}
          </div>

          {/* Description */}
          <div className="mb-8">
            <h2 className="text-xl font-bold dark:text-white mb-3">📖 About this Destination</h2>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{dest.description}</p>
          </div>

          {/* Highlights */}
          <div className="mb-8">
            <h2 className="text-xl font-bold dark:text-white mb-4">🏆 Top Highlights</h2>
            <div className="grid grid-cols-2 gap-3">
              {dest.highlights.map((h, i) => (
                <div key={h} className="flex items-center gap-3 bg-blue-50 dark:bg-blue-900/30 rounded-xl px-4 py-3">
                  <span className="text-blue-500 font-bold">{i + 1}.</span>
                  <span className="text-sm font-medium dark:text-white">{h}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="mb-8">
            <h2 className="text-xl font-bold dark:text-white mb-3">🏷️ Tags</h2>
            <div className="flex flex-wrap gap-2">
              {dest.tags.map(tag => (
                <span key={tag} className="bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 px-4 py-2 rounded-full font-medium text-sm">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex gap-4">
            {booked ? (
              <div className="flex-1 text-center bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300 py-4 rounded-2xl text-lg font-bold">
                ✅ Already Booked!
              </div>
            ) : (
              <button onClick={handleBook}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-2xl text-lg font-bold transition active:scale-95 shadow-md">
                ✈️ Book This Trip — ₹{dest.price.toLocaleString()}
              </button>
            )}
            <button
              onClick={() => dispatch(toggleWishlist(dest.id))}
              className={`px-6 py-4 rounded-2xl text-lg font-bold border-2 transition ${
                wished
                  ? 'border-red-300 bg-red-50 dark:bg-red-900/30 text-red-500'
                  : 'border-gray-200 dark:border-gray-600 dark:text-white hover:border-blue-400'
              }`}
            >
              {wished ? '❤️ Saved' : '🤍 Save'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
