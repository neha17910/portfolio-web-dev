import { configureStore } from '@reduxjs/toolkit'
import tripsReducer    from '../features/trips/tripsSlice'
import wishlistReducer from '../features/wishlist/wishlistSlice'

export const store = configureStore({
  reducer: {
    trips:    tripsReducer,
    wishlist: wishlistReducer,
  },
})
