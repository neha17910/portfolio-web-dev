import { createSlice } from '@reduxjs/toolkit'

const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState: { ids: [], booked: [] },
  reducers: {
    toggleWishlist: (s, { payload }) => {
      if (s.ids.includes(payload)) s.ids = s.ids.filter(i => i !== payload)
      else s.ids.push(payload)
    },
    bookTrip: (s, { payload }) => {
      if (!s.booked.includes(payload)) s.booked.push(payload)
    },
  },
})

export const { toggleWishlist, bookTrip } = wishlistSlice.actions
export default wishlistSlice.reducer
